# Rancang Bangun _Computer Vision System_ (CVS) sebagai Instrumen Prediksi Kualitas Fermentasi Biji Kakao

Project ini berkaitan dengan klasifikasi fermentasi biji kakao (cut-test) dengan menggunakan K-Nearest Neighbor Classifier (KNN).

### Docs
`cocoa_cv.py` segmentasi

Image Segmentation -> BRG to HSV color space conversion -> Feature Extraction -> SVM/RF/other method -> Train model -> ??? -> Profit?